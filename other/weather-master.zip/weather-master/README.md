a simple chrome extension based on angularjs
